# Task

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**crm_user_id** | **int** | id ответственного | [optional] 
**text** | **string** |  | [optional] 
**type** | **string** | тип задачи | [optional] 
**time** | **string** | (timestamp) время выполнения задачи | [optional] 
**element_id** | **int** |  | [optional] 
**element_type** | **int** | тип привязываемого елемента (1 - контакт, 2- сделка, 3 - компания) | [optional] 
**status** | **string** | статус задачи (0 - не завершена, 1 - завершена) | [optional] 
**date_create** | **string** | timestamp | [optional] 
**id** | **int** | id задачи | [optional] 
**last_modified** | **string** | timestamp | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


