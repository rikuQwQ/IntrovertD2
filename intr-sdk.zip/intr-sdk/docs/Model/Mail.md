# Mail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msg** | **string** |  | 
**subject** | **string** |  | 
**from** | [**\Introvert\Model\MailFrom**](MailFrom.md) |  | 
**to** | [**\Introvert\Model\MailTo[]**](MailTo.md) |  | 
**additional_data** | [**\Introvert\Model\MailAdditional**](MailAdditional.md) | Дополнительные параметры, необязательный параметр | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


