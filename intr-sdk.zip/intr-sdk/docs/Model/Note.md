# Note

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**text** | **string** |  | 
**element_id** | **int** |  | 
**element_type** | **string** | 2 (lead), 1 (contact). По умолчанию 2 (lead) | [default to '2']
**note_type** | **string** |  | [optional] 
**date_create** | **string** |  | [optional] 
**last_modified** | **string** |  | [optional] 
**crm_user_id** | **int** |  | [optional] 
**created_user_id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


