# TelegramFilter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**crm_user_id** | **string[]** | фильтр по id | [optional] 
**email** | **string[]** | фильтр по email | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


