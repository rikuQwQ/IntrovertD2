# YadroUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uid** | **int** | id сотрудника | [optional] 
**name** | **string** | Имя | [optional] 
**email** | **string** | Email | [optional] 
**phone** | **int** | Номер мобильного | [optional] 
**amoid** | **int** | id пользователя amoCRM | [optional] 
**enabled** | **int** | Статус активности сотрудника вкл/выкл | [optional] 
**sender_name** | **string** | Имя отправителя | [optional] 
**signature** | **string** | Подпись для писем | [optional] 
**pbx_number** | **int** | Номер назначения в OnlinePBX | [optional] 
**reserve_number** | **int** | Номер для звонков вне рабочее время | [optional] 
**for_new_clients_number** | **int** | Номер для звонков по новым клиентам | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


