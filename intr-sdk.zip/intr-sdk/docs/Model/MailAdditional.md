# MailAdditional

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_id** | **int** | id сущности, к которой будет прикреплено письмо | [optional] 
**entity_type** | **string** | тип сущности, к которой будет прикреплено письмо, в данный момент только lead, по умолчанию lead | [optional] [default to 'lead']
**login** | **string** | логин отпарвителя | [optional] 
**crm_user_id** | **int** | id отправителя | [optional] 
**service** | **string** | Почтовый сервис | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


