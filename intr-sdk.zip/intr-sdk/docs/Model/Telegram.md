# Telegram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string[]** | обязателен если не передан command | [optional] 
**msg** | **string** |  | 
**command** | **string** | обязателен если не передан id | [optional] 
**filter** | [**\Introvert\Model\TelegramFilter**](TelegramFilter.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


