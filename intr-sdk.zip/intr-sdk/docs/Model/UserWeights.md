# UserWeights

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weightall** | **int** | Вес для всех типов заявок | [optional] 
**weightsite** | **int** | Вес для всех заявок с сайта | [optional] 
**weightcall** | **int** | Вес для всех заявок со звонков | [optional] 
**weightmail** | **int** | Вес для всех заявок с почты | [optional] 
**weightvk** | **int** | Вес для заявок с ВК | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


